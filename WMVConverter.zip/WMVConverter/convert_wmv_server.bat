@echo off
setlocal enabledelayedexpansion

:: Windows Server 2012 R2 WMV to MP4 Converter
:: Configured for server environment with logging and error handling

:: Set the input and output folders
set "INPUT_FOLDER=%~dp0"
set "OUTPUT_FOLDER=%~dp0converted"
set "LOG_FOLDER=%~dp0logs"

:: Create output and log folders if they don't exist
if not exist "%OUTPUT_FOLDER%" mkdir "%OUTPUT_FOLDER%"
if not exist "%LOG_FOLDER%" mkdir "%LOG_FOLDER%"

:: Set log file with timestamp
set "LOG_FILE=%LOG_FOLDER%\conversion_%date:~-4,4%%date:~-10,2%%date:~-7,2%_%time:~0,2%%time:~3,2%%time:~6,2%.log"
set "LOG_FILE=%LOG_FILE: =0%"

:: Function to log messages
:log
echo [%date% %time%] %~1 >> "%LOG_FILE%"
echo [%date% %time%] %~1
goto :eof

:: Function to check if running as administrator
:checkAdmin
net session >nul 2>&1
if %errorLevel% == 0 (
    call :log "Administrator privileges confirmed"
    goto :checkFFmpeg
) else (
    call :log "ERROR: This script requires administrator privileges"
    call :log "Please run as administrator or configure scheduled task with elevated privileges"
    pause
    exit /b 1
)

:: Check if FFmpeg is installed
:checkFFmpeg
where ffmpeg >nul 2>&1
if %ERRORLEVEL% equ 0 (
    call :log "FFmpeg is already installed"
    ffmpeg -version | findstr "ffmpeg version" >> "%LOG_FILE%" 2>&1
    goto :startConversion
) else (
    call :log "FFmpeg is not installed. Attempting installation..."
    
    :: Check if Chocolatey is installed
    where choco >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        call :log "Installing Chocolatey package manager..."
        powershell -Command "Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))" >> "%LOG_FILE%" 2>&1
        if %ERRORLEVEL% neq 0 (
            call :log "ERROR: Failed to install Chocolatey"
            call :log "Manual FFmpeg installation required"
            pause
            exit /b 1
        )
        call :log "Chocolatey installed successfully"
    ) else (
        call :log "Chocolatey is already installed"
    )
    
    call :log "Installing FFmpeg using Chocolatey..."
    choco install ffmpeg -y >> "%LOG_FILE%" 2>&1
    if %ERRORLEVEL% neq 0 (
        call :log "ERROR: Failed to install FFmpeg via Chocolatey"
        call :log "Attempting manual download..."
        goto :manualFFmpegInstall
    )
    
    :: Refresh environment variables
    call refreshenv
    call :log "FFmpeg installed successfully via Chocolatey"
)

:manualFFmpegInstall
:: Alternative manual installation method
call :log "Attempting manual FFmpeg installation..."
set "FFMPEG_DIR=%PROGRAMFILES%\ffmpeg"
if not exist "%FFMPEG_DIR%" mkdir "%FFMPEG_DIR%"

:: Download FFmpeg (you may need to adjust the URL for the latest version)
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile '%TEMP%\ffmpeg.zip'}" >> "%LOG_FILE%" 2>&1
if %ERRORLEVEL% neq 0 (
    call :log "ERROR: Failed to download FFmpeg"
    call :log "Please download FFmpeg manually from https://ffmpeg.org/download.html"
    pause
    exit /b 1
)

:: Extract and setup
powershell -Command "Expand-Archive -Path '%TEMP%\ffmpeg.zip' -DestinationPath '%TEMP%\ffmpeg' -Force" >> "%LOG_FILE%" 2>&1
xcopy "%TEMP%\ffmpeg\ffmpeg-*\bin\*" "%FFMPEG_DIR%\" /Y >> "%LOG_FILE%" 2>&1
setx PATH "%PATH%;%FFMPEG_DIR%" /M >> "%LOG_FILE%" 2>&1

:: Clean up
del "%TEMP%\ffmpeg.zip" >> "%LOG_FILE%" 2>&1
rmdir /s /q "%TEMP%\ffmpeg" >> "%LOG_FILE%" 2>&1

:: Verify installation
where ffmpeg >nul 2>&1
if %ERRORLEVEL% equ 0 (
    call :log "Manual FFmpeg installation successful"
) else (
    call :log "ERROR: Manual FFmpeg installation failed"
    call :log "Please restart the script or reboot the server"
    pause
    exit /b 1
)

:startConversion
call :log "Starting WMV to MP4 conversion service"
call :log "Input folder: %INPUT_FOLDER%"
call :log "Output folder: %OUTPUT_FOLDER%"
call :log "Log file: %LOG_FILE%"
call :log "Press Ctrl+C to stop the service"

:: Set conversion parameters optimized for server
set "FFMPEG_PARAMS=-c:v libx264 -crf 23 -preset medium -c:a aac -b:a 128k -movflags +faststart -y"

:loop
:: Find all WMV files in the input folder
set "files_found=0"
for %%F in ("%INPUT_FOLDER%\*.wmv") do (
    set /a files_found+=1
    set "filename=%%~nF"
    set "output_file=%OUTPUT_FOLDER%\!filename!.mp4"
    
    :: Check if the output file already exists
    if not exist "!output_file!" (
        call :log "Converting: %%F"
        ffmpeg -i "%%F" %FFMPEG_PARAMS% "!output_file!" >> "%LOG_FILE%" 2>&1
        if !ERRORLEVEL! equ 0 (
            call :log "SUCCESS: Converted %%F to !output_file!"
        ) else (
            call :log "ERROR: Failed to convert %%F"
        )
    ) else (
        call :log "SKIP: !output_file! already exists"
    )
)

if %files_found% equ 0 (
    call :log "No WMV files found in input folder"
) else (
    call :log "Processed %files_found% WMV files"
)

:: Wait for 30 seconds before checking again (longer interval for server)
call :log "Waiting 30 seconds before next scan..."
timeout /t 30 /nobreak >nul
goto loop 